# NEXUS RED HUD — Galaxy S24 FE (sem root)

Este pacote contém o projeto Android do launcher NEXUS e um widget de tela inicial.
O APK é compilado pelo GitHub Actions; o ZIP do projeto **não é um APK instalável**.

## O que esta versão oferece
- Tela inicial NEXUS existente no projeto.
- Atividade registrada como launcher HOME para poder ser escolhida como tela inicial.
- Widget nativo para a tela inicial com relógio, data e nível atual da bateria.
- Mantém o papel de parede atual do celular; este pacote não instala nem altera wallpaper.
- Sem root, sem telemetria implementada.

## Compilar APK pelo GitHub (como no seu fluxo atual)
1. Envie o conteúdo da pasta `nexus-cyber-launcher` para a raiz do seu repositório GitHub (inclua a pasta `.github`).
2. Abra **Actions** e selecione o workflow **Build NEXUS RED APK**.
3. Execute **Run workflow** ou faça commit/push para `main`.
4. Abra a execução com marca verde e, no final, toque em **Artifacts → NEXUS-Cyber-Launcher-APK** para baixar o ZIP.
5. Extraia esse ZIP e localize `app-debug.apk`.
6. No Galaxy, abra o APK em Meus Arquivos/Downloads. Se solicitado, permita instalação dessa fonte. Instale.


## Correções nesta revisão
- Implementadas as rotinas que faltavam para ler notificações locais, consultar o próximo evento do calendário e consultar o clima atual via Open-Meteo.
- A consulta meteorológica roda em dispatcher de I/O, com timeout de rede e mensagens de fallback quando não há localização recente ou internet.
- Declarada explicitamente a dependência de coroutines usada pela tela inicial.
- O workflow agora faz build limpo, verifica que o APK foi criado e publica o artefato por 14 dias.

## Aplicar como tela inicial
1. Abra Configurações do Android → Aplicativos → Escolher aplicativos padrão → Aplicativo de início (o nome pode variar).
2. Selecione **NEXUS Cyber Launcher**.
3. Para voltar, escolha **One UI Home** no mesmo menu.

## Adicionar o widget HUD
1. Na tela inicial NEXUS, mantenha pressionada uma área vazia.
2. Abra **Widgets**.
3. Procure **NEXUS Cyber Launcher** e arraste o widget NEXUS HUD para a tela.
4. Redimensione segurando o widget, se o launcher permitir.

## Limites reais
- O widget mostra relógio/data e bateria lidos do aparelho quando o widget é atualizado. O Android pode atualizar widgets em intervalos, não a cada segundo.
- Um launcher não pode substituir integralmente a barra de status, central de notificações, tela de bloqueio nem menus internos da One UI. Isso exigiria recursos próprios da Samsung ou permissões especiais.
- O workflow gera um APK de depuração; o pacote não inclui APK pré-compilado. Valide a instalação no dispositivo antes de definir como launcher padrão.

## Compilação local
Abra a pasta `nexus-cyber-launcher` no Android Studio, sincronize o Gradle e execute **Build → Build APK(s)**. O workflow do GitHub já está configurado para gerar o artefato.


## NEXUS RED/BLACK + widget de música

A interface do launcher usa painéis pretos, detalhes vermelho intenso e texto cinza/branco; o papel de parede que já está configurado no celular permanece inalterado. Inclui dois widgets de tela inicial: **NEXUS HUD** (hora/data/bateria) e **NEXUS AUDIO** (faixa atual e botões anterior, reproduzir/pausar e próxima).

### Ativar controles de música no Samsung
1. Instale o APK gerado pelo workflow do GitHub Actions.
2. Abra **Configurações > Aplicativos > Acesso especial > Acesso a notificações** (o nome pode variar por versão do One UI).
3. Ative **NEXUS Media Controls**. Essa permissão permite ler os metadados da sessão de mídia ativa e enviar comandos ao player; não é necessária para usar o restante do launcher.
4. Inicie uma música em Spotify, YouTube Music ou outro player compatível com sessões de mídia do Android.
5. Na tela inicial, mantenha pressionado um espaço vazio > **Widgets** > **NEXUS Cyber Launcher** > **NEXUS AUDIO** e adicione o widget.
6. Use os botões ⏮, ▶/Ⅱ e ⏭ para voltar, pausar/reproduzir e avançar. A disponibilidade de faixa/ações depende do app de música e da sessão de mídia ativa.

O widget de música é independente do widget HUD. Se a permissão de acesso a notificações não estiver ativada, toque no aviso vermelho do widget para abrir a tela de permissões.


## Integrações Android reais (build de integração)

- **Notificações:** `NexusMediaNotificationListener` recebe notificações somente depois que o usuário ativa o acesso especial do Android. Guarda no armazenamento privado do app até 10 títulos/textos recentes, sem enviar esses dados para um servidor. A tela ALERTAS permite abrir o app de origem e limpar a lista.
- **Música:** usa `MediaSessionManager` e controladores de mídia do Android. Requer a mesma autorização de acesso a notificações; só controla players que publicam uma sessão de mídia compatível.
- **Sistema:** hora/data e bateria são lidas do aparelho. Indicadores de CPU/RAM simulados foram removidos; o vetor é identificado como sensor não ativo.
- **Calendário:** a tela ALERTAS pode consultar o próximo evento após a permissão `READ_CALENDAR`. A consulta usa o provedor de calendário do Android.
- **Clima:** usa a API pública Open-Meteo com a localização mais recente disponível no aparelho. Requer internet e permissão de localização; não grava a localização nem mostra temperatura inventada. Se o Android não tiver uma localização recente, o módulo informa que a localização está indisponível.
- **Aplicativos:** o diretório lista atividades que o Android disponibiliza como iniciáveis (apps que podem ser abertos pelo launcher), respeitando a visibilidade de pacotes do Android.
- **Cores e wallpaper:** RUBI, CIBER, MATRIX, ALERTA e NEXUS RED / BLACK permanecem no seletor de paletas. O projeto não define, substitui ou inclui um wallpaper; o fundo configurado no telefone fica intacto.

### Permissões usadas
- Acesso a notificações: concedido manualmente em Configurações do Android; necessário para alertas e controle de mídia.
- Calendário: solicitado somente quando você toca em “Consultar próximo evento”.
- Localização aproximada/precisa: solicitada somente quando você toca em “Atualizar clima”.
- Internet: usada apenas para a consulta meteorológica Open-Meteo.

### Limitações e privacidade
O serviço de notificações pode receber conteúdo privado; a lista é armazenada localmente no armazenamento privado do app e pode ser apagada pelo botão LIMPAR. Não há sincronização remota implementada. O clima depende de uma localização recente fornecida pelo Android. Gmail, WhatsApp e Instagram não fornecem automaticamente todos os dados internos das contas; o NEXUS lê as notificações que esses apps publicam, e os itens podem ser tocados para abrir o app. Não lê e-mails/conversas diretamente nem contorna proteções desses aplicativos.

**Validação:** os arquivos XML são validados ao empacotar. Este ambiente não possui Android SDK/Gradle instalado, portanto o APK não foi compilado aqui. Execute o workflow GitHub Actions e teste no S24 FE antes de usar como launcher padrão.


## Theme Sync (RED / BLACK)

A seleção existente em **SISTEMA → PERFIL CROMÁTICO** continua sendo usada. Ao selecionar uma paleta, o índice é salvo em `nexus_preferences` e os widgets HUD e Música são atualizados para usar a paleta atual. A opção `NEXUS RED / BLACK` é a quinta paleta; o papel de parede não é alterado por esse recurso.

### Limites de integração no Android/Samsung

- **Ícones:** o launcher pode desenhar molduras/acentos com a paleta ativa, mas trocar a imagem de todos os ícones requer um pacote de imagens associado aos nomes dos pacotes. Os ícones originais continuam disponíveis; este patch não inventa nem inclui imagens para cada app instalado.
- **Teclado:** um launcher não pode mudar as cores internas do Samsung Keyboard/Gboard diretamente. É necessário aplicar um tema compatível pelo próprio teclado ou criar/instalar um IME NEXUS separado e selecioná-lo explicitamente nas configurações do Android.
- **Painel rápido e barra de status:** um app comum não pode substituir o painel rápido nativo da One UI. Theme Park/Good Lock pode oferecer personalização parcial, conforme versão/país, mas deve ser aplicado separadamente e não é controlado por este launcher.
- **Widgets:** RemoteViews oferece um conjunto limitado de propriedades. A paleta sincroniza as cores de texto e o fundo dos controles compatíveis; detalhes decorativos definidos diretamente no XML podem não mudar todos.
- **Build:** execute o workflow Android no GitHub Actions para validar a compilação. Este pacote não foi compilado localmente neste ambiente.


## Personalizar ícones no launcher

Na gaveta **APPS**, toque num app para abrir. Mantenha pressionada a imagem do ícone para escolher um PNG/JPG/WebP do armazenamento. A seleção fica guardada localmente para aquele pacote e substitui apenas a imagem mostrada no NEXUS, sem alterar o ícone do app em outros launchers. Use imagens quadradas de 256–512 px para melhor resultado. O ícone original volta a aparecer se a imagem escolhida for removida ou ficar inacessível.

## NEXUS Keyboard (IME experimental)

O projeto inclui um método de entrada próprio, com teclas escuras e contorno/acento da paleta ativa. Para ativar: Configurações Android → Gerenciamento geral → Lista de teclados e padrão → ative NEXUS Keyboard; depois escolha-o em Teclado padrão. O Android mostra avisos de segurança ao ativar um teclado de terceiros. Ative-o somente se confiar no APK e no código.

Este teclado é uma versão inicial: letras minúsculas, espaço, apagar e Enter estão implementados; shift, alternância real para números/símbolos, sugestões, autocorreção, emoji e layouts avançados ainda não estão completos. Ele lê a paleta salva pelo NEXUS quando a vista do teclado é criada; pode ser necessário fechar e reabrir o teclado após trocar de paleta.
