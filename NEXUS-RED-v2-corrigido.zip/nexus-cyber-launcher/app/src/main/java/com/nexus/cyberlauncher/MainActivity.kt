package com.nexus.cyberlauncher

import android.Manifest
import android.content.Intent
import android.content.Context
import android.content.pm.PackageManager as AndroidPackageManager
import android.provider.CalendarContract
import android.location.LocationManager
import android.location.Location
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.ContextCompat
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.combinedClickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL

private val Background = Color(0xFF030303)
private val Panel = Color(0xFF101010)
private val Muted = Color(0xFF9A9A9A)
private val ThemeRed = Color(0xFFFF233F)
private val ThemeCyan = Color(0xFF39DDEB)
private val ThemeGreen = Color(0xFF57F287)
private val ThemeYellow = Color(0xFFFFD45E)
private val ThemeBlackSecondary = Color(0xFF777777)

private data class NexusPalette(val name: String, val accent: Color, val secondary: Color)
private val palettes = listOf(
    NexusPalette("RUBI", ThemeRed, ThemeCyan),
    NexusPalette("CIBER", ThemeCyan, ThemeRed),
    NexusPalette("MATRIX", ThemeGreen, ThemeCyan),
    NexusPalette("ALERTA", ThemeYellow, ThemeRed),
    NexusPalette("NEXUS RED / BLACK", ThemeRed, ThemeBlackSecondary)
)

data class LaunchableApp(val label: String, val packageName: String, val icon: Drawable)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexusApp(apps = loadApps(), onLaunchApp = ::launchPackage) }
    }

    private fun loadApps(): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, AndroidPackageManager.MATCH_ALL)
            .mapNotNull { info ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                LaunchableApp(info.loadLabel(packageManager).toString(), pkg, info.loadIcon(packageManager))
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun launchPackage(packageName: String) {
        packageManager.getLaunchIntentForPackage(packageName)?.let(::startActivity)
    }
}

@Composable
private fun NexusApp(apps: List<LaunchableApp>, onLaunchApp: (String) -> Unit) {
    val context = LocalContext.current
    val preferences = remember(context) {
        context.getSharedPreferences("nexus_preferences", android.content.Context.MODE_PRIVATE)
    }
    var page by remember { mutableStateOf("home") }
    var search by remember { mutableStateOf("") }
    var notificationItems by remember { mutableStateOf(readNexusNotifications(context)) }
    var weatherText by remember { mutableStateOf("CLIMA NÃO CONSULTADO") }
    val coroutineScope = rememberCoroutineScope()
    val locationPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestMultiplePermissions()
    ) { result ->
        if (result.values.any { it }) {
            coroutineScope.launch {
                weatherText = fetchRealWeather(context)
            }
        } else weatherText = "PERMISSÃO DE LOCALIZAÇÃO NEGADA"
    }
    LaunchedEffect(Unit) {
        while (true) {
            notificationItems = readNexusNotifications(context)
            delay(2500)
        }
    }
    val calendarPermission = rememberLauncherForActivityResult(
        ActivityResultContracts.RequestPermission()
    ) { granted ->
        if (granted) {
            val events = readNextCalendarEvent(context)
            android.widget.Toast.makeText(context, events, android.widget.Toast.LENGTH_LONG).show()
        }
    }
    var iconTargetPackage by remember { mutableStateOf<String?>(null) }
    val iconPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        val target = iconTargetPackage
        if (uri != null && target != null) {
            try { context.contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION) } catch (_: Exception) {}
            preferences.edit().putString("icon_uri_$target", uri.toString()).apply()
        }
        iconTargetPackage = null
    }
    var paletteIndex by remember {
        mutableIntStateOf(preferences.getInt("palette_index", 0).coerceIn(0, palettes.lastIndex))
    }
    val palette = palettes[paletteIndex]
    val filteredApps = remember(apps, search) {
        apps.filter { it.label.contains(search, ignoreCase = true) }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = palette.accent,
        secondary = palette.secondary,
        background = Background,
        surface = Panel
    )) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF151515), Background, Color(0xFF000000)))
            )
        ) {
            Column(
                Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Header(palette)
                Spacer(Modifier.height(10.dp))

                when (page) {
                    "apps" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { page = "home" }) {
                                Icon(Icons.Default.ArrowBack, "Voltar", tint = palette.secondary)
                            }
                            Row(
                                Modifier.weight(1f).border(1.dp, palette.accent, CutCornerShape(8.dp))
                                    .background(Panel).padding(horizontal = 10.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Search, null, tint = palette.secondary)
                                Spacer(Modifier.width(8.dp))
                                BasicTextField(
                                    value = search, onValueChange = { search = it },
                                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                                    decorationBox = { inner ->
                                        if (search.isEmpty()) Text("Pesquisar aplicativos...", color = Muted, fontSize = 13.sp)
                                        inner()
                                    }
                                )
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        SectionTitle("DIRETÓRIO DE APLICATIVOS", palette.accent)
                        Text("Toque para abrir · mantenha o ícone pressionado para personalizar a imagem", color = Muted, fontSize = 9.sp)
                        Spacer(Modifier.height(8.dp))
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 74.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(filteredApps, key = { it.packageName }) { app ->
                                Column(
                                    Modifier.fillMaxWidth().padding(5.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(Modifier.size(48.dp).border(1.dp, palette.accent.copy(alpha = .7f), CutCornerShape(9.dp))
                                        .background(Panel, CutCornerShape(9.dp)).padding(5.dp)
                                        .combinedClickable(onClick = { onLaunchApp(app.packageName) }, onLongClick = {
                                            iconTargetPackage = app.packageName
                                            iconPicker.launch(arrayOf("image/png", "image/jpeg", "image/webp"))
                                        }), contentAlignment = Alignment.Center) {
                                        val customUri = preferences.getString("icon_uri_${app.packageName}", null)
                                        AppIcon(app.icon, app.label, customUri)
                                    }
                                    Spacer(Modifier.height(5.dp))
                                    Text(app.label, color = Color.White, fontSize = 10.sp, maxLines = 2, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }
                    "notifications" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { page = "home" }) {
                                Icon(Icons.Default.ArrowBack, "Voltar", tint = palette.secondary)
                            }
                            SectionTitle("CENTRAL NEXUS // NOTIFICAÇÕES", palette.accent)
                        }
                        Spacer(Modifier.height(8.dp))
                        HudPanel("EVENTOS RECEBIDOS DO ANDROID", palette.accent, palette.secondary) {
                            Text("Os dados vêm do acesso a notificações autorizado pelo usuário.", color = Muted, fontSize = 10.sp)
                            Spacer(Modifier.height(8.dp))
                            if (notificationItems.isEmpty()) {
                                Text("Nenhuma notificação salva. Ative o acesso abaixo e aguarde notificações reais.", color = Color.White, fontSize = 12.sp)
                            } else {
                                notificationItems.forEach { item ->
                                    Column(Modifier.fillMaxWidth().clickable {
                                        context.packageManager.getLaunchIntentForPackage(item.third)?.let { context.startActivity(it) }
                                    }.padding(vertical = 6.dp)) {
                                        Text(item.first, color = palette.accent, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                        Text(item.second, color = Color.White, fontSize = 11.sp)
                                        Text(item.third, color = Muted, fontSize = 9.sp)
                                    }
                                    HorizontalDivider(color = Color(0xFF303030))
                                }
                            }
                            Spacer(Modifier.height(8.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                Button(onClick = {
                                    context.startActivity(Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
                                }) { Text("AUTORIZAR") }
                                OutlinedButton(onClick = {
                                    context.getSharedPreferences("nexus_notifications", android.content.Context.MODE_PRIVATE)
                                        .edit().putString("items", "[]").apply()
                                    notificationItems = emptyList()
                                }) { Text("LIMPAR") }
                            }
                            Text("Toque em uma notificação para abrir o app de origem. O NEXUS guarda até 10 itens localmente.", color = Muted, fontSize = 9.sp)
                        }
                        Spacer(Modifier.height(8.dp))
                        HudPanel("CALENDÁRIO", palette.secondary, palette.accent) {
                            Text("Consultar o próximo evento exige permissão de leitura do calendário.", color = Muted, fontSize = 11.sp)
                            Button(onClick = {
                                if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) == AndroidPackageManager.PERMISSION_GRANTED) {
                                    android.widget.Toast.makeText(context, readNextCalendarEvent(context), android.widget.Toast.LENGTH_LONG).show()
                                } else calendarPermission.launch(Manifest.permission.READ_CALENDAR)
                            }) { Text("CONSULTAR PRÓXIMO EVENTO") }
                        }
                        Spacer(Modifier.weight(1f))
                    }
                    "settings" -> {
                        SectionTitle("CONFIGURAÇÃO DE SISTEMA", palette.accent)
                        Spacer(Modifier.height(10.dp))
                        HudPanel("PERFIL CROMÁTICO", palette.accent, palette.secondary) {
                            Text("Selecione a assinatura visual da interface.", color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(12.dp))
                            palettes.forEachIndexed { index, item ->
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 5.dp)
                                        .border(1.dp, if (paletteIndex == index) item.accent else Color(0xFF303030), CutCornerShape(6.dp))
                                        .background(if (paletteIndex == index) item.accent.copy(alpha = .09f) else Color.Transparent, CutCornerShape(6.dp))
                                        .clickable {
                                            paletteIndex = index
                                            preferences.edit().putInt("palette_index", index).apply()
                                            NexusThemeSync.apply(context, index)
                                        }.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.size(14.dp).background(item.accent, RoundedCornerShape(3.dp)))
                                    Spacer(Modifier.width(10.dp))
                                    Text(item.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.weight(1f))
                                    if (paletteIndex == index) Text("ATIVO", color = item.accent, fontSize = 9.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        HudPanel("SOBRE O NEXUS", palette.secondary, palette.accent) {
                            InfoLine("BUILD", "0.2.0 • protótipo")
                            InfoLine("IDIOMA", "Português (Brasil)")
                            InfoLine("DADOS", "Sem telemetria implementada")
                            InfoLine("MODO", "Interface tática")
                        }
                        Spacer(Modifier.weight(1f))
                    }
                    else -> {
                        Row(verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) {
                                Text("HORA LOCAL", color = palette.secondary, fontSize = 9.sp, letterSpacing = 2.sp)
                                Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
                                    color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Light)
                                Text(SimpleDateFormat("EEE, dd MMM", Locale("pt", "BR")).format(Date()).uppercase(Locale("pt", "BR")),
                                    color = palette.accent, fontSize = 10.sp, letterSpacing = 1.5.sp)
                            }
                            CompassPanel(palette.accent, palette.secondary)
                        }
                        Spacer(Modifier.height(10.dp))
                        HudPanel("STATUS DO SISTEMA", palette.accent, palette.secondary) {
                            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                MetricCell("ESTADO", "PRONTO", palette.accent, Modifier.weight(1f))
                                MetricCell("PERFIL", palette.name, palette.secondary, Modifier.weight(1f))
                                MetricCell("VERSÃO", "0.2", palette.accent, Modifier.weight(1f))
                            }
                            Spacer(Modifier.height(10.dp))
                            InfoLine("BATERIA REAL", readBatteryPercent(context))
                            InfoLine("NOTIFICAÇÕES", if (notificationItems.isEmpty()) "AGUARDANDO ACESSO" else "${notificationItems.size} RECEBIDAS")
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            HudPanel("ATALHOS", palette.secondary, palette.accent, Modifier.weight(1f)) {
                                ShortcutLine("APLICATIVOS", "Abrir diretório", palette.secondary) { page = "apps" }
                                ShortcutLine("CONFIGURAÇÕES", "Tema e perfil", palette.accent) { page = "settings" }
                                ShortcutLine("COMUNICAÇÃO", "Abrir apps", palette.secondary) { page = "apps" }
                                ShortcutLine("NOTIFICAÇÕES", "${notificationItems.size} itens locais", palette.accent) { page = "notifications" }
                            }
                            HudPanel("AMBIENTE", palette.accent, palette.secondary, Modifier.weight(1f)) {
                                Text(weatherText.take(28), color = palette.accent, fontSize = 14.sp, fontWeight = FontWeight.Bold)
                                Text("MÓDULO CLIMA // OPEN-METEO", color = Muted, fontSize = 9.sp)
                                Spacer(Modifier.height(8.dp))
                                Text("Consulta real pela localização do aparelho; requer internet e autorização.", color = Muted, fontSize = 10.sp)
                                Spacer(Modifier.height(6.dp))
                                Text("ATUALIZAR CLIMA", color = palette.secondary, fontSize = 9.sp,
                                    modifier = Modifier.clickable {
                                        val fine = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) == AndroidPackageManager.PERMISSION_GRANTED
                                        val coarse = ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) == AndroidPackageManager.PERMISSION_GRANTED
                                        if (fine || coarse) {
                                            coroutineScope.launch { weatherText = fetchRealWeather(context) }
                                        } else locationPermission.launch(arrayOf(Manifest.permission.ACCESS_COARSE_LOCATION, Manifest.permission.ACCESS_FINE_LOCATION))
                                    })
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        HudPanel("LOG DE OPERAÇÕES", palette.secondary, palette.accent) {
                            InfoLine("07:42:18", "Interface inicializada")
                            InfoLine("07:42:19", "Perfil ${palette.name} carregado")
                            InfoLine("07:42:20", "Módulos de navegação prontos")
                        }
                        Spacer(Modifier.weight(1f))
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth().border(1.dp, palette.accent.copy(alpha = .55f), CutCornerShape(8.dp))
                        .background(Color(0xDD080808), CutCornerShape(8.dp)).padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NavItem(Icons.Default.Home, "BASE", page == "home", palette.accent) { page = "home" }
                    NavItem(Icons.Default.Apps, "APPS", page == "apps", palette.secondary) { page = "apps" }
                    NavItem(Icons.Default.Apps, "ALERTAS", page == "notifications", palette.accent) { page = "notifications" }
                    NavItem(Icons.Default.Settings, "SISTEMA", page == "settings", palette.accent) { page = "settings" }
                }
                Text("NEXUS // CYBER TACTICAL INTERFACE", color = Muted, fontSize = 8.sp,
                    letterSpacing = 1.4.sp, modifier = Modifier.fillMaxWidth().padding(top = 5.dp), textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun Header(palette: NexusPalette) {
    Row(
        Modifier.fillMaxWidth().border(1.dp, palette.accent.copy(alpha = .75f), CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp))
            .background(Color(0xDD080808), CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(28.dp).border(1.dp, palette.accent, CutCornerShape(5.dp)), contentAlignment = Alignment.Center) {
            Text("N", color = palette.accent, fontWeight = FontWeight.Black, fontSize = 17.sp)
        }
        Spacer(Modifier.width(9.dp))
        Column {
            Text("NEXUS", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("CYBER TACTICAL SYSTEM", color = palette.secondary, fontSize = 8.sp, letterSpacing = 1.3.sp)
        }
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text("● ONLINE", color = palette.accent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Text("SECURE LINK", color = Muted, fontSize = 8.sp)
        }
    }
}

@Composable
private fun SectionTitle(text: String, accent: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(16.dp).background(accent))
        Spacer(Modifier.width(7.dp))
        Text(text, color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f).height(1.dp).background(accent.copy(alpha = .45f)))
    }
}

@Composable
private fun HudPanel(
    title: String,
    accent: Color,
    secondary: Color,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier.border(1.dp, accent.copy(alpha = .8f), CutCornerShape(topStart = 5.dp, bottomEnd = 12.dp))
            .background(Brush.verticalGradient(listOf(Color(0xF2181818), Color(0xF9080808))), CutCornerShape(topStart = 5.dp, bottomEnd = 12.dp))
            .padding(10.dp)
    ) {
        Text("▰  $title", color = accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(8.dp))
        content()
        Spacer(Modifier.height(2.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(secondary.copy(alpha = .45f)))
    }
}

@Composable
private fun MetricCell(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Column(modifier.border(1.dp, accent.copy(alpha = .55f), CutCornerShape(5.dp)).padding(7.dp)) {
        Text(label, color = Muted, fontSize = 8.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ProgressLine(label: String, fraction: Float, accent: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 8.sp, modifier = Modifier.width(92.dp))
        Box(Modifier.weight(1f).height(5.dp).background(Color(0xFF292929), RoundedCornerShape(2.dp))) {
            Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().background(accent, RoundedCornerShape(2.dp)))
        }
        Text("${(fraction * 100).toInt()}%", color = accent, fontSize = 8.sp, modifier = Modifier.width(28.dp), textAlign = TextAlign.End)
    }
    Spacer(Modifier.height(5.dp))
}

@Composable
private fun ShortcutLine(title: String, subtitle: String, accent: Color, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 7.dp)) {
        Text("› $title", color = accent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 8.sp)
    }
    HorizontalDivider(color = Color(0xFF303030))
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("› $label", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(0.8f))
        Text(value, color = Color.White, fontSize = 9.sp, textAlign = TextAlign.End, modifier = Modifier.weight(1.2f))
    }
}

@Composable
private fun CompassPanel(accent: Color, secondary: Color) {
    Column(
        Modifier.width(90.dp).border(1.dp, secondary.copy(alpha = .7f), CutCornerShape(8.dp))
            .background(Panel, CutCornerShape(8.dp)).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("VECTOR", color = Muted, fontSize = 8.sp)
        Text("N", color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text("⊙", color = secondary, fontSize = 35.sp)
        Text("SENSOR NÃO ATIVO", color = accent, fontSize = 7.sp)
    }
}

@Composable
private fun AppIcon(icon: Drawable, label: String, customUri: String? = null) {
    AndroidView(
        factory = { context -> ImageView(context).apply {
            contentDescription = label
            scaleType = ImageView.ScaleType.FIT_CENTER
            setImageDrawable(icon)
        } },
        update = { view ->
            val custom = try { customUri?.let { android.net.Uri.parse(it) }?.let { view.context.contentResolver.openInputStream(it)?.use { stream -> android.graphics.drawable.Drawable.createFromStream(stream, null) } } } catch (_: Exception) { null }
            view.setImageDrawable(custom ?: icon)
        },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun NavItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit
) {
    TextButton(onClick = onClick) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = label, tint = if (selected) accent else Muted, modifier = Modifier.size(18.dp))
            Text(label, color = if (selected) accent else Muted, fontSize = 8.sp, letterSpacing = .6.sp)
        }
    }
}


/** Reads the most recent notifications saved by NexusMediaNotificationListener. */
private fun readNexusNotifications(context: Context): List<Triple<String, String, String>> {
    val raw = context.getSharedPreferences("nexus_notifications", Context.MODE_PRIVATE)
        .getString("items", "[]") ?: "[]"
    return try {
        val array = JSONArray(raw)
        (0 until array.length()).mapNotNull { index ->
            val item = array.optJSONObject(index) ?: return@mapNotNull null
            val title = item.optString("title", "Notificação").ifBlank { "Notificação" }
            val text = item.optString("text", "").ifBlank { "Sem conteúdo" }
            val pkg = item.optString("package", "")
            Triple(title, text, pkg)
        }.take(10)
    } catch (_: Exception) {
        emptyList()
    }
}

/** Looks up the next calendar event, with the caller responsible for checking permission. */
private fun readNextCalendarEvent(context: Context): String {
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.READ_CALENDAR) != AndroidPackageManager.PERMISSION_GRANTED) {
        return "Permissão do calendário não concedida."
    }
    val now = System.currentTimeMillis()
    val end = now + 30L * 24 * 60 * 60 * 1000
    val builder = CalendarContract.Instances.CONTENT_URI.buildUpon()
    android.content.ContentUris.appendId(builder, now)
    android.content.ContentUris.appendId(builder, end)
    val projection = arrayOf(CalendarContract.Instances.TITLE, CalendarContract.Instances.BEGIN)
    return try {
        context.contentResolver.query(
            builder.build(), projection,
            "${CalendarContract.Instances.BEGIN} >= ?",
            arrayOf(now.toString()),
            "${CalendarContract.Instances.BEGIN} ASC"
        )?.use { cursor ->
            if (cursor.moveToFirst()) {
                val title = cursor.getString(0)?.takeIf { it.isNotBlank() } ?: "Evento sem título"
                val begin = cursor.getLong(1)
                val date = SimpleDateFormat("dd/MM HH:mm", Locale.getDefault()).format(Date(begin))
                "$title · $date"
            } else "Nenhum evento encontrado nos próximos 30 dias."
        } ?: "Não foi possível consultar o calendário."
    } catch (_: SecurityException) {
        "Acesso ao calendário não autorizado."
    } catch (_: Exception) {
        "Erro ao consultar o calendário."
    }
}

/** Fetches current weather from Open-Meteo without blocking the UI thread. */
private suspend fun fetchRealWeather(context: Context): String = withContext(Dispatchers.IO) {
    if (ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_FINE_LOCATION) != AndroidPackageManager.PERMISSION_GRANTED &&
        ContextCompat.checkSelfPermission(context, Manifest.permission.ACCESS_COARSE_LOCATION) != AndroidPackageManager.PERMISSION_GRANTED) {
        return@withContext "PERMISSÃO DE LOCALIZAÇÃO NECESSÁRIA"
    }
    try {
        val manager = context.getSystemService(Context.LOCATION_SERVICE) as LocationManager
        val location: Location? = listOf(LocationManager.NETWORK_PROVIDER, LocationManager.GPS_PROVIDER)
            .asSequence()
            .mapNotNull { provider -> try { manager.getLastKnownLocation(provider) } catch (_: Exception) { null } }
            .maxByOrNull { it.time }
        if (location == null) return@withContext "LOCALIZAÇÃO INDISPONÍVEL"
        val url = URL("https://api.open-meteo.com/v1/forecast?latitude=${location.latitude}&longitude=${location.longitude}&current=temperature_2m,weather_code&timezone=auto")
        val connection = (url.openConnection() as HttpURLConnection).apply {
            connectTimeout = 8000
            readTimeout = 8000
            requestMethod = "GET"
        }
        try {
            if (connection.responseCode !in 200..299) return@withContext "CLIMA INDISPONÍVEL"
            val body = connection.inputStream.bufferedReader().use { it.readText() }
            val current = org.json.JSONObject(body).optJSONObject("current")
                ?: return@withContext "DADOS DO CLIMA INDISPONÍVEIS"
            val temperature = current.optDouble("temperature_2m", Double.NaN)
            val code = current.optInt("weather_code", -1)
            if (temperature.isNaN()) "DADOS DO CLIMA INDISPONÍVEIS"
            else "${temperature.toInt()}°C · ${weatherDescription(code)}"
        } finally {
            connection.disconnect()
        }
    } catch (_: Exception) {
        "CLIMA OFFLINE / TENTE NOVAMENTE"
    }
}

private fun weatherDescription(code: Int): String = when (code) {
    0 -> "CÉU LIMPO"
    1, 2 -> "PARCIALMENTE NUBLADO"
    3 -> "NUBLADO"
    45, 48 -> "NEBLINA"
    51, 53, 55, 56, 57 -> "GAROA"
    61, 63, 65, 66, 67, 80, 81, 82 -> "CHUVA"
    71, 73, 75, 77, 85, 86 -> "NEVE"
    else -> "CONDIÇÃO $code"
}
