package com.nexus.cyberlauncher

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.Context
import android.content.Intent
import android.os.BatteryManager
import android.content.IntentFilter
import android.widget.RemoteViews
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class NexusHudWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(
        context: Context,
        manager: AppWidgetManager,
        appWidgetIds: IntArray
    ) {
        appWidgetIds.forEach { id -> updateWidget(context, manager, id) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == NexusThemeSync.ACTION_THEME_CHANGED) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(android.content.ComponentName(context, NexusHudWidgetProvider::class.java))
            ids.forEach { updateWidget(context, manager, it) }
        }
    }

    companion object {
        fun updateWidget(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_nexus_hud)
            val colors = NexusThemeSync.colors(context)
            views.setTextColor(R.id.widget_date, colors.accent)
            views.setTextColor(R.id.widget_battery, colors.accent)
            views.setInt(R.id.widget_root, "setBackgroundColor", colors.background)
            val now = Date()
            views.setTextViewText(R.id.widget_time, SimpleDateFormat("HH:mm", Locale.getDefault()).format(now))
            views.setTextViewText(R.id.widget_date, SimpleDateFormat("EEE, dd MMM", Locale.getDefault()).format(now).uppercase(Locale.getDefault()))

            val batteryIntent = context.registerReceiver(null, IntentFilter(Intent.ACTION_BATTERY_CHANGED))
            val level = batteryIntent?.getIntExtra(BatteryManager.EXTRA_LEVEL, -1) ?: -1
            val scale = batteryIntent?.getIntExtra(BatteryManager.EXTRA_SCALE, 100) ?: 100
            val pct = if (level >= 0 && scale > 0) (level * 100 / scale) else -1
            views.setTextViewText(R.id.widget_battery, if (pct >= 0) "BATERIA  $pct%" else "BATERIA  --")

            val launch = Intent(context, MainActivity::class.java)
            val pending = PendingIntent.getActivity(
                context, 0, launch,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            views.setOnClickPendingIntent(R.id.widget_root, pending)
            manager.updateAppWidget(id, views)
        }
    }
}
