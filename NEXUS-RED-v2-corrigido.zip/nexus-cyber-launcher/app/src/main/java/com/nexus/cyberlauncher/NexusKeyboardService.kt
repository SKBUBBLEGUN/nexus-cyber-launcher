package com.nexus.cyberlauncher

import android.inputmethodservice.InputMethodService
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.inputmethod.EditorInfo
import android.widget.Button
import android.widget.LinearLayout

class NexusKeyboardService : InputMethodService() {
    private fun palette(): Int {
        val index = getSharedPreferences("nexus_preferences", MODE_PRIVATE).getInt("palette_index", 4)
        return when (index) {
            1 -> Color.rgb(57,221,235)
            2 -> Color.rgb(87,242,135)
            3 -> Color.rgb(255,212,94)
            else -> Color.rgb(255,35,63)
        }
    }

    override fun onCreateInputView(): View {
        val accent = palette()
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(5, 7, 5, 7)
            setBackgroundColor(Color.rgb(7,7,7))
        }
        fun row(keys: List<String>, weight: Float = 1f) {
            val line = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER }
            keys.forEach { key ->
                val b = Button(this).apply {
                    text = key
                    setTextColor(if (key == "↵" || key == "⌫") accent else Color.WHITE)
                    textSize = 15f
                    typeface = Typeface.create("sans-serif-condensed", Typeface.BOLD)
                    isAllCaps = false
                    background = GradientDrawable().apply {
                        setColor(Color.rgb(22,22,22))
                        setStroke(1, accent)
                        cornerRadius = 7f
                    }
                    setOnClickListener { handleKey(key) }
                }
                line.addView(b, LinearLayout.LayoutParams(0, 48, if (key == "ESPAÇO") 4f else 1f).apply { setMargins(2,2,2,2) })
            }
            root.addView(line)
        }
        val brand = android.widget.TextView(this).apply {
            text = "N E X U S   //   TACTICAL KEYBOARD"
            setTextColor(accent); textSize = 10f; gravity = Gravity.CENTER
        }
        root.addView(brand, LinearLayout.LayoutParams(-1, 24))
        row(listOf("q","w","e","r","t","y","u","i","o","p"))
        row(listOf("a","s","d","f","g","h","j","k","l"))
        row(listOf("⇧","z","x","c","v","b","n","m","⌫"))
        row(listOf("?123",",","ESPAÇO",".","↵"))
        return root
    }

    private fun handleKey(key: String) {
        val ic = currentInputConnection ?: return
        when (key) {
            "⌫" -> ic.deleteSurroundingText(1, 0)
            "↵" -> {
                val action = currentInputEditorInfo?.imeOptions?.and(EditorInfo.IME_MASK_ACTION) ?: EditorInfo.IME_ACTION_UNSPECIFIED
                if (action != EditorInfo.IME_ACTION_NONE && action != EditorInfo.IME_ACTION_UNSPECIFIED) ic.performEditorAction(action)
                else ic.commitText("\\n", 1)
            }
            "ESPAÇO" -> ic.commitText(" ", 1)
            "⇧" -> { /* layout simple: shift reserved for future uppercase toggle */ }
            "?123" -> ic.commitText("?123", 1)
            else -> ic.commitText(key, 1)
        }
    }
}
