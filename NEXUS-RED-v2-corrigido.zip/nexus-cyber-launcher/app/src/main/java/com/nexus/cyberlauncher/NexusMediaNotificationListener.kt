package com.nexus.cyberlauncher

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification
import android.app.Notification
import org.json.JSONArray
import org.json.JSONObject

class NexusMediaNotificationListener : NotificationListenerService() {
    override fun onListenerConnected() {
        super.onListenerConnected()
        NexusMusicWidgetActions.refreshAll(this)
        activeNotifications?.forEach { saveNotification(it) }
    }

    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        if (sbn != null && sbn.packageName != packageName) saveNotification(sbn)
        NexusMusicWidgetActions.refreshAll(this)
    }

    override fun onNotificationRemoved(sbn: StatusBarNotification?) {
        NexusMusicWidgetActions.refreshAll(this)
    }

    private fun saveNotification(sbn: StatusBarNotification) {
        val extras = sbn.notification.extras ?: return
        val title = extras.getCharSequence(Notification.EXTRA_TITLE)?.toString()?.trim().orEmpty()
        val text = (extras.getCharSequence(Notification.EXTRA_BIG_TEXT)
            ?: extras.getCharSequence(Notification.EXTRA_TEXT))?.toString()?.trim().orEmpty()
        if (title.isBlank() && text.isBlank()) return
        val prefs = getSharedPreferences("nexus_notifications", MODE_PRIVATE)
        val old = try { JSONArray(prefs.getString("items", "[]")) } catch (_: Exception) { JSONArray() }
        val item = JSONObject().put("title", title.take(120))
            .put("text", text.take(300)).put("package", sbn.packageName)
            .put("time", sbn.postTime)
        val next = JSONArray().put(item)
        for (i in 0 until minOf(old.length(), 9)) {
            val previous = old.optJSONObject(i) ?: continue
            if (previous.optString("package") == sbn.packageName &&
                previous.optString("title") == title && previous.optString("text") == text) continue
            next.put(previous)
        }
        prefs.edit().putString("items", next.toString()).apply()
    }
}
