package com.nexus.cyberlauncher

import android.app.PendingIntent
import android.appwidget.AppWidgetManager
import android.appwidget.AppWidgetProvider
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.media.session.MediaController
import android.media.session.MediaSessionManager
import android.provider.Settings
import android.view.KeyEvent
import android.widget.RemoteViews

class NexusMusicWidgetProvider : AppWidgetProvider() {
    override fun onUpdate(context: Context, manager: AppWidgetManager, ids: IntArray) {
        ids.forEach { NexusMusicWidgetActions.update(context, manager, it) }
    }

    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        if (intent.action == NexusThemeSync.ACTION_THEME_CHANGED) {
            NexusMusicWidgetActions.refreshAll(context)
        }
    }
}

class NexusMusicWidgetActions : AppWidgetProvider() {
    override fun onReceive(context: Context, intent: Intent) {
        super.onReceive(context, intent)
        when (intent.action) {
            ACTION_PREVIOUS -> control(context, MediaAction.PREVIOUS)
            ACTION_PLAY_PAUSE -> control(context, MediaAction.PLAY_PAUSE)
            ACTION_NEXT -> control(context, MediaAction.NEXT)
            ACTION_ACCESS -> {
                val settings = Intent(Settings.ACTION_NOTIFICATION_LISTENER_SETTINGS)
                    .addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(settings)
            }
        }
        refreshAll(context)
    }

    companion object {
        const val ACTION_PREVIOUS = "com.nexus.cyberlauncher.music.PREVIOUS"
        const val ACTION_PLAY_PAUSE = "com.nexus.cyberlauncher.music.PLAY_PAUSE"
        const val ACTION_NEXT = "com.nexus.cyberlauncher.music.NEXT"
        const val ACTION_ACCESS = "com.nexus.cyberlauncher.music.ACCESS"

        private enum class MediaAction { PREVIOUS, PLAY_PAUSE, NEXT }

        fun refreshAll(context: Context) {
            val manager = AppWidgetManager.getInstance(context)
            val ids = manager.getAppWidgetIds(ComponentName(context, NexusMusicWidgetProvider::class.java))
            ids.forEach { update(context, manager, it) }
        }

        fun update(context: Context, manager: AppWidgetManager, id: Int) {
            val views = RemoteViews(context.packageName, R.layout.widget_nexus_music)
            val colors = NexusThemeSync.colors(context)
            views.setTextColor(R.id.music_status, colors.accent)
            views.setTextColor(R.id.music_previous, colors.accent)
            views.setTextColor(R.id.music_play_pause, colors.accent)
            views.setTextColor(R.id.music_next, colors.accent)
            views.setInt(R.id.music_previous, "setBackgroundColor", colors.background)
            views.setInt(R.id.music_play_pause, "setBackgroundColor", colors.background)
            views.setInt(R.id.music_next, "setBackgroundColor", colors.background)
            var title = "NENHUMA FAIXA ATIVA"
            var artist = "Abra seu app de música"
            var playing = false
            var access = false
            try {
                val sessions = activeSessions(context)
                access = true
                val controller = sessions.firstOrNull { it.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING }
                    ?: sessions.firstOrNull()
                controller?.let {
                    val metadata = it.metadata
                    title = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_TITLE) ?: "REPRODUÇÃO PRONTA"
                    artist = metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ARTIST)
                        ?: metadata?.getString(android.media.MediaMetadata.METADATA_KEY_ALBUM) ?: it.packageName
                    playing = it.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING
                }
            } catch (_: SecurityException) {
                title = "ATIVAR CONTROLE DE MÍDIA"
                artist = "Toque aqui e permita NEXUS"
            } catch (_: Exception) {
                title = "CONTROLE DE MÍDIA INDISPONÍVEL"
                artist = "Abra um app de música"
            }
            views.setTextViewText(R.id.music_title, title.take(42))
            views.setTextViewText(R.id.music_artist, artist.take(48))
            views.setTextViewText(R.id.music_play_pause, if (playing) "Ⅱ" else "▶")
            views.setTextViewText(R.id.music_status, if (access) "NEXUS AUDIO // LINK" else "PERMISSÃO NECESSÁRIA")
            views.setOnClickPendingIntent(R.id.music_status, pending(context, ACTION_ACCESS, 4))
            views.setOnClickPendingIntent(R.id.music_previous, pending(context, ACTION_PREVIOUS, 1))
            views.setOnClickPendingIntent(R.id.music_play_pause, pending(context, ACTION_PLAY_PAUSE, 2))
            views.setOnClickPendingIntent(R.id.music_next, pending(context, ACTION_NEXT, 3))
            manager.updateAppWidget(id, views)
        }

        private fun pending(context: Context, action: String, request: Int): PendingIntent {
            val intent = Intent(context, NexusMusicWidgetActions::class.java).setAction(action)
            return PendingIntent.getBroadcast(context, request, intent,
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE)
        }

        private fun activeSessions(context: Context): List<MediaController> {
            val manager = context.getSystemService(Context.MEDIA_SESSION_SERVICE) as MediaSessionManager
            return manager.getActiveSessions(ComponentName(context, NexusMediaNotificationListener::class.java))
        }

        private fun control(context: Context, action: MediaAction) {
            val controller = try {
                activeSessions(context).firstOrNull { it.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING }
                    ?: activeSessions(context).firstOrNull()
            } catch (_: Exception) { null } ?: return
            when (action) {
                MediaAction.PREVIOUS -> controller.transportControls.skipToPrevious()
                MediaAction.NEXT -> controller.transportControls.skipToNext()
                MediaAction.PLAY_PAUSE -> {
                    if (controller.playbackState?.state == android.media.session.PlaybackState.STATE_PLAYING) {
                        controller.transportControls.pause()
                    } else {
                        controller.transportControls.play()
                    }
                }
            }
        }
    }
}
