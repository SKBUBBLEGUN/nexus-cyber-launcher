package com.nexus.cyberlauncher

import android.appwidget.AppWidgetManager
import android.content.ComponentName
import android.content.Context
import android.content.Intent
import android.graphics.Color as AndroidColor

/**
 * Shared palette contract for the launcher and Android RemoteViews widgets.
 * Keep indices aligned with MainActivity.palettes.
 */
object NexusThemeSync {
    const val ACTION_THEME_CHANGED = "com.nexus.cyberlauncher.action.THEME_CHANGED"
    private const val PREFS = "nexus_preferences"
    private const val KEY_PALETTE = "palette_index"

    data class Colors(val accent: Int, val secondary: Int, val background: Int = AndroidColor.rgb(5, 5, 5))

    fun colors(context: Context): Colors {
        val index = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
            .getInt(KEY_PALETTE, 0)
        return when (index) {
            1 -> Colors(AndroidColor.rgb(57, 221, 235), AndroidColor.rgb(255, 35, 63))
            2 -> Colors(AndroidColor.rgb(87, 242, 135), AndroidColor.rgb(57, 221, 235))
            3 -> Colors(AndroidColor.rgb(255, 212, 94), AndroidColor.rgb(255, 35, 63))
            4 -> Colors(AndroidColor.rgb(255, 35, 63), AndroidColor.rgb(119, 119, 119))
            else -> Colors(AndroidColor.rgb(255, 35, 63), AndroidColor.rgb(57, 221, 235))
        }
    }

    fun apply(context: Context, paletteIndex: Int) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE).edit()
            .putInt(KEY_PALETTE, paletteIndex.coerceIn(0, 4)).apply()
        context.sendBroadcast(Intent(ACTION_THEME_CHANGED).setPackage(context.packageName))
        refreshWidgets(context)
    }

    fun refreshWidgets(context: Context) {
        val manager = AppWidgetManager.getInstance(context)
        val hud = manager.getAppWidgetIds(ComponentName(context, NexusHudWidgetProvider::class.java))
        hud.forEach { NexusHudWidgetProvider.updateWidget(context, manager, it) }
        val music = manager.getAppWidgetIds(ComponentName(context, NexusMusicWidgetProvider::class.java))
        music.forEach { NexusMusicWidgetActions.update(context, manager, it) }
    }
}
