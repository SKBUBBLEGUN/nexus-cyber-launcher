# NEXUS Cyber Launcher — protótipo tático v0.2

Projeto inicial Android em Kotlin + Jetpack Compose, inspirado no vídeo de referência: interface tática vertical, painéis segmentados, indicadores, linhas de estado e paletas de cores selecionáveis.

## Implementado nesta versão
- Tela HOME com painéis HUD, relógio, indicadores visuais e log demonstrativo.
- Gaveta de aplicativos instalados com busca e abertura.
- Configurações com troca imediata e persistente entre quatro paletas: RUBI (vermelho/ciano), CIBER (ciano/vermelho), MATRIX (verde/ciano) e ALERTA (amarelo/vermelho). A escolha é salva localmente no aparelho.
- Interface em português e tema escuro.
- Atividade declarada como HOME para poder ser escolhida como launcher.
- Sem telemetria ou coleta de dados implementada.

## Requisitos
- Android Studio recente.
- JDK 17.
- Android SDK Platform 35.
- Dispositivo Android 8.0 (API 26) ou superior para testes.

## Abrir e compilar
1. Extraia o ZIP.
2. Abra a pasta `nexus-cyber-launcher` no Android Studio.
3. Aguarde a sincronização do Gradle. Instale os SDKs solicitados pelo Android Studio.
4. Conecte o Samsung por USB com Depuração USB ativada, ou use um emulador.
5. Selecione **Build > Build APK(s)**.
6. Alternativamente, após configurar o Gradle Wrapper, execute `gradlew.bat assembleDebug` no Windows ou `./gradlew assembleDebug` no macOS/Linux.
7. O APK de depuração normalmente aparece em `app/build/outputs/apk/debug/app-debug.apk`.
8. Instale o APK e pressione Início. Selecione **NEXUS Cyber Launcher** como aplicativo de tela inicial.

## Limites de personalização do Android
- Um launcher pode substituir a tela inicial e fornecer gaveta de apps, widgets próprios e atalhos. Não pode, por si só, substituir universalmente a tela de bloqueio, a central de notificações, Configurações, a barra de status, telas internas de outros aplicativos ou toda a interface One UI.
- Para personalizar outros elementos, use recursos oficiais da Samsung (Temas/Good Lock, quando disponíveis no modelo/região) e ajustes do Android. Esses componentes permanecem sob controle do sistema.

## Notas técnicas
- O projeto ainda precisa ser compilado e testado em aparelho real; não é um APK pronto.
- O ZIP não inclui binários do Gradle Wrapper. O Android Studio pode configurar o wrapper/Gradle compatível; use a versão sugerida pelo plugin Android.
- O painel de clima, os níveis e o log são demonstrativos, não leituras reais do sistema. A versão atual não coleta bateria, RAM, clima ou notificações.
- A paleta escolhida é salva localmente usando SharedPreferences. Não há sincronização em nuvem.
- A aparência é inspirada no vídeo, não uma cópia exata dos recursos do vídeo. A tela de bloqueio, status bar e painéis do sistema Samsung não podem ser substituídos integralmente por um launcher comum.
- Antes de distribuir, valide desempenho, acessibilidade, privacidade, compatibilidade por modelo e assinatura do APK.

## Estrutura
- `app/src/main/java/com/nexus/cyberlauncher/MainActivity.kt`: telas, paletas e navegação.
- `app/src/main/AndroidManifest.xml`: declara a atividade de launcher/HOME.
- `app/build.gradle.kts`: configuração Android/Kotlin/Compose.

## Próximas melhorias
1. Persistir paleta e layout com Preferences DataStore.
2. Painel de widgets redimensionáveis e favoritos.
3. Papel de parede de referência e pacote de ícones.
4. Gestos configuráveis e animações.
5. Integração real de bateria, clima e notificações com APIs e permissões adequadas.
6. Testes de layout em diferentes densidades, tamanhos de tela e versões One UI.


## Gerar o APK sem instalar Android Studio no celular (GitHub Actions)
O projeto inclui `.github/workflows/android-build.yml` para compilar o APK em um runner do GitHub.

1. Crie/entre em uma conta no GitHub e crie um repositório novo.
2. Envie todos os arquivos desta pasta para o repositório (incluindo a pasta `.github`).
3. No repositório, abra a aba **Actions** e selecione **Build NEXUS Cyber Launcher APK**.
4. Toque em **Run workflow** (ou aguarde a compilação após enviar para a branch `main`).
5. Quando terminar, abra a execução concluída e baixe o artefato **NEXUS-Cyber-Launcher-APK**.
6. Extraia o ZIP do artefato para encontrar `app-debug.apk`; transfira/abra o APK no Galaxy e permita a instalação dessa fonte quando o Android solicitar.

A compilação depende do GitHub e de acesso à internet. O APK de depuração não é uma versão publicada na Play Store. Revise e teste no seu aparelho antes de usar como tela inicial.
