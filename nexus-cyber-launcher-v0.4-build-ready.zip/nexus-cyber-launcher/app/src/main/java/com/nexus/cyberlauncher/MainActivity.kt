package com.nexus.cyberlauncher

import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.drawable.Drawable
import android.os.Bundle
import android.widget.ImageView
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.CutCornerShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.compose.ui.platform.LocalContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

private val Background = Color(0xFF071014)
private val Panel = Color(0xFF0D1B20)
private val Muted = Color(0xFF9DB7B8)
private val ThemeRed = Color(0xFFFF465B)
private val ThemeCyan = Color(0xFF38E8F5)
private val ThemeGreen = Color(0xFF8CFF8A)
private val ThemeYellow = Color(0xFFFFD45E)

private data class NexusPalette(val name: String, val accent: Color, val secondary: Color)
private val palettes = listOf(
    NexusPalette("RUBI", ThemeRed, ThemeCyan),
    NexusPalette("CIBER", ThemeCyan, ThemeRed),
    NexusPalette("MATRIX", ThemeGreen, ThemeCyan),
    NexusPalette("ALERTA", ThemeYellow, ThemeRed)
)

data class LaunchableApp(val label: String, val packageName: String, val icon: Drawable)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { NexusApp(apps = loadApps(), onLaunchApp = ::launchPackage) }
    }

    private fun loadApps(): List<LaunchableApp> {
        val intent = Intent(Intent.ACTION_MAIN, null).addCategory(Intent.CATEGORY_LAUNCHER)
        return packageManager.queryIntentActivities(intent, PackageManager.MATCH_ALL)
            .mapNotNull { info ->
                val pkg = info.activityInfo?.packageName ?: return@mapNotNull null
                LaunchableApp(info.loadLabel(packageManager).toString(), pkg, info.loadIcon(packageManager))
            }
            .distinctBy { it.packageName }
            .sortedBy { it.label.lowercase(Locale.getDefault()) }
    }

    private fun launchPackage(packageName: String) {
        packageManager.getLaunchIntentForPackage(packageName)?.let(::startActivity)
    }
}

@Composable
private fun NexusApp(apps: List<LaunchableApp>, onLaunchApp: (String) -> Unit) {
    val context = LocalContext.current
    val preferences = remember(context) {
        context.getSharedPreferences("nexus_preferences", android.content.Context.MODE_PRIVATE)
    }
    var page by remember { mutableStateOf("home") }
    var search by remember { mutableStateOf("") }
    var paletteIndex by remember {
        mutableIntStateOf(preferences.getInt("palette_index", 0).coerceIn(0, palettes.lastIndex))
    }
    val palette = palettes[paletteIndex]
    val filteredApps = remember(apps, search) {
        apps.filter { it.label.contains(search, ignoreCase = true) }
    }

    MaterialTheme(colorScheme = darkColorScheme(
        primary = palette.accent,
        secondary = palette.secondary,
        background = Background,
        surface = Panel
    )) {
        Box(
            Modifier.fillMaxSize().background(
                Brush.verticalGradient(listOf(Color(0xFF102328), Background, Color(0xFF05090C)))
            )
        ) {
            Column(
                Modifier.fillMaxSize().systemBarsPadding().padding(horizontal = 14.dp, vertical = 8.dp)
            ) {
                Header(palette)
                Spacer(Modifier.height(10.dp))

                when (page) {
                    "apps" -> {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { page = "home" }) {
                                Icon(Icons.Default.ArrowBack, "Voltar", tint = palette.secondary)
                            }
                            Row(
                                Modifier.weight(1f).border(1.dp, palette.accent, CutCornerShape(8.dp))
                                    .background(Panel).padding(horizontal = 10.dp, vertical = 12.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(Icons.Default.Search, null, tint = palette.secondary)
                                Spacer(Modifier.width(8.dp))
                                BasicTextField(
                                    value = search, onValueChange = { search = it },
                                    singleLine = true, modifier = Modifier.fillMaxWidth(),
                                    textStyle = androidx.compose.ui.text.TextStyle(color = Color.White, fontSize = 14.sp),
                                    decorationBox = { inner ->
                                        if (search.isEmpty()) Text("Pesquisar aplicativos...", color = Muted, fontSize = 13.sp)
                                        inner()
                                    }
                                )
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        SectionTitle("DIRETÓRIO DE APLICATIVOS", palette.accent)
                        Spacer(Modifier.height(8.dp))
                        LazyVerticalGrid(
                            columns = GridCells.Adaptive(minSize = 74.dp),
                            verticalArrangement = Arrangement.spacedBy(10.dp),
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.weight(1f)
                        ) {
                            items(filteredApps, key = { it.packageName }) { app ->
                                Column(
                                    Modifier.fillMaxWidth().clickable { onLaunchApp(app.packageName) }.padding(5.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Box(Modifier.size(48.dp).border(1.dp, palette.accent.copy(alpha = .7f), CutCornerShape(9.dp))
                                        .background(Panel, CutCornerShape(9.dp)).padding(5.dp), contentAlignment = Alignment.Center) {
                                        AppIcon(app.icon, app.label)
                                    }
                                    Spacer(Modifier.height(5.dp))
                                    Text(app.label, color = Color.White, fontSize = 10.sp, maxLines = 2, textAlign = TextAlign.Center)
                                }
                            }
                        }
                    }
                    "settings" -> {
                        SectionTitle("CONFIGURAÇÃO DE SISTEMA", palette.accent)
                        Spacer(Modifier.height(10.dp))
                        HudPanel("PERFIL CROMÁTICO", palette.accent, palette.secondary) {
                            Text("Selecione a assinatura visual da interface.", color = Muted, fontSize = 12.sp)
                            Spacer(Modifier.height(12.dp))
                            palettes.forEachIndexed { index, item ->
                                Row(
                                    Modifier.fillMaxWidth().padding(vertical = 5.dp)
                                        .border(1.dp, if (paletteIndex == index) item.accent else Color(0xFF263A40), CutCornerShape(6.dp))
                                        .background(if (paletteIndex == index) item.accent.copy(alpha = .09f) else Color.Transparent, CutCornerShape(6.dp))
                                        .clickable {
                                            paletteIndex = index
                                            preferences.edit().putInt("palette_index", index).apply()
                                        }.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Box(Modifier.size(14.dp).background(item.accent, RoundedCornerShape(3.dp)))
                                    Spacer(Modifier.width(10.dp))
                                    Text(item.name, color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    Spacer(Modifier.weight(1f))
                                    if (paletteIndex == index) Text("ATIVO", color = item.accent, fontSize = 9.sp)
                                }
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        HudPanel("SOBRE O NEXUS", palette.secondary, palette.accent) {
                            InfoLine("BUILD", "0.2.0 • protótipo")
                            InfoLine("IDIOMA", "Português (Brasil)")
                            InfoLine("DADOS", "Sem telemetria implementada")
                            InfoLine("MODO", "Interface tática")
                        }
                        Spacer(Modifier.weight(1f))
                    }
                    else -> {
                        Row(verticalAlignment = Alignment.Top) {
                            Column(Modifier.weight(1f)) {
                                Text("HORA LOCAL", color = palette.secondary, fontSize = 9.sp, letterSpacing = 2.sp)
                                Text(SimpleDateFormat("HH:mm", Locale.getDefault()).format(Date()),
                                    color = Color.White, fontSize = 48.sp, fontWeight = FontWeight.Light)
                                Text(SimpleDateFormat("EEE, dd MMM", Locale("pt", "BR")).format(Date()).uppercase(Locale("pt", "BR")),
                                    color = palette.accent, fontSize = 10.sp, letterSpacing = 1.5.sp)
                            }
                            CompassPanel(palette.accent, palette.secondary)
                        }
                        Spacer(Modifier.height(10.dp))
                        HudPanel("STATUS DO SISTEMA", palette.accent, palette.secondary) {
                            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                MetricCell("ESTADO", "PRONTO", palette.accent, Modifier.weight(1f))
                                MetricCell("PERFIL", palette.name, palette.secondary, Modifier.weight(1f))
                                MetricCell("VERSÃO", "0.2", palette.accent, Modifier.weight(1f))
                            }
                            Spacer(Modifier.height(10.dp))
                            ProgressLine("NEXUS CORE", .82f, palette.accent)
                            ProgressLine("LINK DE DADOS", .64f, palette.secondary)
                        }
                        Spacer(Modifier.height(10.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            HudPanel("ATALHOS", palette.secondary, palette.accent, Modifier.weight(1f)) {
                                ShortcutLine("APLICATIVOS", "Abrir diretório", palette.secondary) { page = "apps" }
                                ShortcutLine("CONFIGURAÇÕES", "Tema e perfil", palette.accent) { page = "settings" }
                                ShortcutLine("COMUNICAÇÃO", "Abrir apps", palette.secondary) { page = "apps" }
                            }
                            HudPanel("AMBIENTE", palette.accent, palette.secondary, Modifier.weight(1f)) {
                                Text("32°C", color = palette.accent, fontSize = 30.sp, fontWeight = FontWeight.Light)
                                Text("MÓDULO CLIMA", color = Muted, fontSize = 9.sp)
                                Spacer(Modifier.height(8.dp))
                                Text("DADOS DEMONSTRATIVOS", color = palette.secondary, fontSize = 8.sp)
                                Text("Integração meteorológica ainda não configurada.", color = Muted, fontSize = 10.sp)
                            }
                        }
                        Spacer(Modifier.height(10.dp))
                        HudPanel("LOG DE OPERAÇÕES", palette.secondary, palette.accent) {
                            InfoLine("07:42:18", "Interface inicializada")
                            InfoLine("07:42:19", "Perfil ${palette.name} carregado")
                            InfoLine("07:42:20", "Módulos de navegação prontos")
                        }
                        Spacer(Modifier.weight(1f))
                    }
                }

                Spacer(Modifier.height(8.dp))
                Row(
                    Modifier.fillMaxWidth().border(1.dp, palette.accent.copy(alpha = .55f), CutCornerShape(8.dp))
                        .background(Color(0xDD081116), CutCornerShape(8.dp)).padding(vertical = 2.dp),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    NavItem(Icons.Default.Home, "BASE", page == "home", palette.accent) { page = "home" }
                    NavItem(Icons.Default.Apps, "APPS", page == "apps", palette.secondary) { page = "apps" }
                    NavItem(Icons.Default.Settings, "SISTEMA", page == "settings", palette.accent) { page = "settings" }
                }
                Text("NEXUS // CYBER TACTICAL INTERFACE", color = Muted, fontSize = 8.sp,
                    letterSpacing = 1.4.sp, modifier = Modifier.fillMaxWidth().padding(top = 5.dp), textAlign = TextAlign.Center)
            }
        }
    }
}

@Composable
private fun Header(palette: NexusPalette) {
    Row(
        Modifier.fillMaxWidth().border(1.dp, palette.accent.copy(alpha = .75f), CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp))
            .background(Color(0xDD0A151A), CutCornerShape(topStart = 10.dp, bottomEnd = 10.dp)).padding(10.dp),
        verticalAlignment = Alignment.CenterVertically
    ) {
        Box(Modifier.size(28.dp).border(1.dp, palette.accent, CutCornerShape(5.dp)), contentAlignment = Alignment.Center) {
            Text("N", color = palette.accent, fontWeight = FontWeight.Black, fontSize = 17.sp)
        }
        Spacer(Modifier.width(9.dp))
        Column {
            Text("NEXUS", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Black, letterSpacing = 3.sp)
            Text("CYBER TACTICAL SYSTEM", color = palette.secondary, fontSize = 8.sp, letterSpacing = 1.3.sp)
        }
        Spacer(Modifier.weight(1f))
        Column(horizontalAlignment = Alignment.End) {
            Text("● ONLINE", color = palette.accent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
            Text("SECURE LINK", color = Muted, fontSize = 8.sp)
        }
    }
}

@Composable
private fun SectionTitle(text: String, accent: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Box(Modifier.width(4.dp).height(16.dp).background(accent))
        Spacer(Modifier.width(7.dp))
        Text(text, color = accent, fontSize = 11.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.4.sp)
        Spacer(Modifier.width(8.dp))
        Box(Modifier.weight(1f).height(1.dp).background(accent.copy(alpha = .45f)))
    }
}

@Composable
private fun HudPanel(
    title: String,
    accent: Color,
    secondary: Color,
    modifier: Modifier = Modifier,
    content: @Composable ColumnScope.() -> Unit
) {
    Column(
        modifier.border(1.dp, accent.copy(alpha = .8f), CutCornerShape(topStart = 5.dp, bottomEnd = 12.dp))
            .background(Brush.verticalGradient(listOf(Color(0xF20D1D22), Color(0xF9081115))), CutCornerShape(topStart = 5.dp, bottomEnd = 12.dp))
            .padding(10.dp)
    ) {
        Text("▰  $title", color = accent, fontSize = 9.sp, fontWeight = FontWeight.Bold, letterSpacing = 1.2.sp)
        Spacer(Modifier.height(8.dp))
        content()
        Spacer(Modifier.height(2.dp))
        Box(Modifier.fillMaxWidth().height(1.dp).background(secondary.copy(alpha = .45f)))
    }
}

@Composable
private fun MetricCell(label: String, value: String, accent: Color, modifier: Modifier = Modifier) {
    Column(modifier.border(1.dp, accent.copy(alpha = .55f), CutCornerShape(5.dp)).padding(7.dp)) {
        Text(label, color = Muted, fontSize = 8.sp)
        Spacer(Modifier.height(4.dp))
        Text(value, color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
    }
}

@Composable
private fun ProgressLine(label: String, fraction: Float, accent: Color) {
    Row(verticalAlignment = Alignment.CenterVertically) {
        Text(label, color = Muted, fontSize = 8.sp, modifier = Modifier.width(92.dp))
        Box(Modifier.weight(1f).height(5.dp).background(Color(0xFF26383D), RoundedCornerShape(2.dp))) {
            Box(Modifier.fillMaxWidth(fraction).fillMaxHeight().background(accent, RoundedCornerShape(2.dp)))
        }
        Text("${(fraction * 100).toInt()}%", color = accent, fontSize = 8.sp, modifier = Modifier.width(28.dp), textAlign = TextAlign.End)
    }
    Spacer(Modifier.height(5.dp))
}

@Composable
private fun ShortcutLine(title: String, subtitle: String, accent: Color, onClick: () -> Unit) {
    Column(Modifier.fillMaxWidth().clickable(onClick = onClick).padding(vertical = 7.dp)) {
        Text("› $title", color = accent, fontSize = 9.sp, fontWeight = FontWeight.Bold)
        Text(subtitle, color = Muted, fontSize = 8.sp)
    }
    HorizontalDivider(color = Color(0xFF293B40))
}

@Composable
private fun InfoLine(label: String, value: String) {
    Row(Modifier.fillMaxWidth().padding(vertical = 3.dp), verticalAlignment = Alignment.CenterVertically) {
        Text("› $label", color = Muted, fontSize = 9.sp, modifier = Modifier.weight(0.8f))
        Text(value, color = Color.White, fontSize = 9.sp, textAlign = TextAlign.End, modifier = Modifier.weight(1.2f))
    }
}

@Composable
private fun CompassPanel(accent: Color, secondary: Color) {
    Column(
        Modifier.width(90.dp).border(1.dp, secondary.copy(alpha = .7f), CutCornerShape(8.dp))
            .background(Panel, CutCornerShape(8.dp)).padding(8.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text("VECTOR", color = Muted, fontSize = 8.sp)
        Text("N", color = accent, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        Text("⊙", color = secondary, fontSize = 35.sp)
        Text("042° / NE", color = accent, fontSize = 8.sp)
    }
}

@Composable
private fun AppIcon(icon: Drawable, label: String) {
    AndroidView(
        factory = { context -> ImageView(context).apply { setImageDrawable(icon); contentDescription = label; scaleType = ImageView.ScaleType.FIT_CENTER } },
        update = { it.setImageDrawable(icon) },
        modifier = Modifier.fillMaxSize()
    )
}

@Composable
private fun NavItem(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    label: String,
    selected: Boolean,
    accent: Color,
    onClick: () -> Unit
) {
    TextButton(onClick = onClick) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(icon, contentDescription = label, tint = if (selected) accent else Muted, modifier = Modifier.size(18.dp))
            Text(label, color = if (selected) accent else Muted, fontSize = 8.sp, letterSpacing = .6.sp)
        }
    }
}
